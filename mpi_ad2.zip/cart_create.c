#include <studio.h>
#include "mpi.h"

int main
{
    int myrank, nprocs;
    int dim[2]=(0,0)
    int newrank, newprocs;

    MPI_Init(NULL, NULL);
    NPI_Comm_rank(MPI_COMM_WORLD, &myrank)
    NPI_Comm_size(MPI_COMM_WORLD, &myrank)





}